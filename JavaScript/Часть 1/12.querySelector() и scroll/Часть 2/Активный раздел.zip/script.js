let arrH1 = container.querySelectorAll('h1');
let arrLi = nav.querySelectorAll('li');
document.addEventListener('scroll', function() {
    if (window.pageYOffset >= (document.body.scrollHeight / 4)) {
        up.style.opacity = 1;
    }
    else up.style.opacity = 0;
    for (let index in arrH1) {
        if (arrH1[index].getBoundingClientRect().top <= 0) {
            arrLi[index].style.color = '#44d';
        }
        
    }
})